# ============================================================
# ##     ##    ###          ## #### ##     ## ######## ########  ##     ##
# ###   ###   ## ##         ##  ##  ###   ### ##       ##     ## ##     ##
# #### ####  ##   ##        ##  ##  #### #### ##       ##     ## ##     ##
# ## ### ## ##     ##       ##  ##  ## ### ## ######   ########  ##     ##
# ##     ## ######### ##    ##  ##  ##     ## ##       ##   ##   ##     ##
# ##     ## ##     ## ##    ##  ##  ##     ## ##       ##    ##  ##     ##
# ##     ## ##     ##  ######  #### ##     ## ######## ##     ##  #######
#
#  Tool    : majimeru_reference  v1
#  Author  : majimeru + とびうおぴょんぴょん
#  What    : Blender tool: Maya-style references - link a collection from
#            another .blend, make a library override, reload / relocate.
#  YouTube : https://www.youtube.com/@3DCGいろいろ
#  License : GPL-3.0 - free to use, modify and share.
#            Keep this note when you share it.
# ============================================================

bl_info = {
    "name": "Majimeru Reference",
    "description": "Maya-style references for Blender: link collections from other .blend files and make library overrides",
    "author": "majimeru + tobiuo pyonpyon",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "category": "Scene",
    "location": "3D View > Sidebar (N) > Majimeru",
}

import json
import os

import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup


# ---------------------------------------------------------------- helpers

def scan_collections(filepath):
    """Return the collection names inside a .blend file (nothing is loaded)."""
    names = []
    with bpy.data.libraries.load(filepath, link=False) as (from_data, _to_data):
        names = list(from_data.collections)
    return names


def collection_items(self, context):
    try:
        names = json.loads(self.names_json or "[]")
    except Exception:
        names = []
    if not names:
        return [("NONE", "(no collections - pick a file first)", "")]
    return [(n, n, "") for n in names]


def refresh_scan(context, props):
    path = bpy.path.abspath(props.src_file) if props.src_file else ""
    if path and os.path.isfile(path) and path.lower().endswith(".blend"):
        try:
            props.names_json = json.dumps(scan_collections(path), ensure_ascii=False)
            return True
        except Exception:
            props.names_json = "[]"
    else:
        props.names_json = "[]"
    return False


def on_src_file_update(self, context):
    refresh_scan(context, self)


def make_override_for_instance(context, inst):
    """Run Object > Library Override > Make on a collection-instance object."""
    view_layer = context.view_layer
    for obj in view_layer.objects:
        obj.select_set(False)
    inst.select_set(True)
    view_layer.objects.active = inst
    with context.temp_override(view_layer=view_layer, active_object=inst,
                               selected_objects=[inst]):
        bpy.ops.object.make_override_library()


# ---------------------------------------------------------------- properties

class MAJREF_Props(PropertyGroup):
    src_file: StringProperty(
        name="元ファイル",
        description="リンク元の .blend ファイル",
        subtype="FILE_PATH",
        update=on_src_file_update,
    )
    names_json: StringProperty(default="[]", options={"HIDDEN"})
    collection: EnumProperty(
        name="コレクション",
        description="リンクするコレクション",
        items=collection_items,
    )
    auto_override: BoolProperty(
        name="リンクしたら自動でオーバーライドも作る",
        description="ONだと、リンクした直後にポーズや配置ができる状態まで一気に進む（Mayaのリファレンスでアニメーションするのと同じ）",
        default=True,
    )


# ---------------------------------------------------------------- operators

class MAJREF_OT_pick_file(Operator):
    bl_idname = "majref.pick_file"
    bl_label = "元ファイルを選ぶ"
    bl_description = "リンク元の .blend ファイルを選ぶ"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.blend", options={"HIDDEN"})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        context.scene.maj_ref.src_file = self.filepath
        return {"FINISHED"}


class MAJREF_OT_scan(Operator):
    bl_idname = "majref.scan"
    bl_label = "中身を調べる"
    bl_description = "元ファイルの中にあるコレクションの一覧を取り直す"

    def execute(self, context):
        props = context.scene.maj_ref
        if refresh_scan(context, props):
            names = json.loads(props.names_json or "[]")
            self.report({"INFO"}, "コレクションが %d 個見つかったよ" % len(names))
        else:
            self.report({"ERROR"}, "元ファイルが選ばれてないか、.blend やないよ")
            return {"CANCELLED"}
        return {"FINISHED"}


class MAJREF_OT_link(Operator):
    bl_idname = "majref.link"
    bl_label = "リンクする"
    bl_description = "選んだコレクションをこのシーンにリンクする（Mayaのリファレンス読み込み）"

    def execute(self, context):
        props = context.scene.maj_ref
        path = bpy.path.abspath(props.src_file) if props.src_file else ""
        if not path or not os.path.isfile(path):
            self.report({"ERROR"}, "先に元ファイルを選んでね")
            return {"CANCELLED"}
        name = props.collection
        names = json.loads(props.names_json or "[]")
        if name == "NONE" or name not in names:
            self.report({"ERROR"}, "リンクするコレクションが無いよ。「中身を調べる」を押し直してみて")
            return {"CANCELLED"}

        # Already linked from the same file? (avoid silent duplicates)
        for coll in bpy.data.collections:
            if coll.name == name and coll.library and \
                    os.path.normpath(bpy.path.abspath(coll.library.filepath)) == os.path.normpath(path):
                self.report({"WARNING"}, "「%s」はもうリンクされてるよ" % name)
                return {"CANCELLED"}

        with bpy.data.libraries.load(path, link=True) as (_from, to_data):
            to_data.collections = [name]
        linked = to_data.collections[0] if to_data.collections else None
        if linked is None:
            self.report({"ERROR"}, "リンクに失敗したよ")
            return {"CANCELLED"}

        inst = bpy.data.objects.new(linked.name, None)
        inst.instance_type = "COLLECTION"
        inst.instance_collection = linked
        context.scene.collection.objects.link(inst)

        if props.auto_override:
            try:
                make_override_for_instance(context, inst)
            except Exception as exc:
                self.report({"WARNING"}, "リンクはできたけど、オーバーライドは失敗: %s" % exc)
                return {"FINISHED"}
            self.report({"INFO"}, "「%s」をリンク＋オーバーライドしたよ。ポーズや配置ができる状態やで" % name)
        else:
            self.report({"INFO"}, "「%s」をリンクしたよ" % name)
        return {"FINISHED"}


class MAJREF_OT_override_selected(Operator):
    bl_idname = "majref.override_selected"
    bl_label = "オーバーライドを作る（選んだもの）"
    bl_description = "選んだリンク中コレクションの実体（エンプティ）に、ライブラリオーバーライドを作る"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.instance_collection is not None

    def execute(self, context):
        inst = context.active_object
        target = inst.instance_collection
        if target is None or target.library is None:
            self.report({"ERROR"}, "リンク中のコレクションの実体（エンプティ）を選んでね")
            return {"CANCELLED"}
        if target.override_library is not None:
            self.report({"WARNING"}, "もうオーバーライド済みやよ")
            return {"CANCELLED"}
        try:
            make_override_for_instance(context, inst)
        except Exception as exc:
            self.report({"ERROR"}, "オーバーライドに失敗: %s" % exc)
            return {"CANCELLED"}
        self.report({"INFO"}, "オーバーライドを作ったよ")
        return {"FINISHED"}


class MAJREF_OT_reload_one(Operator):
    bl_idname = "majref.reload_one"
    bl_label = "読み直す"
    bl_description = "このライブラリを読み直す（元ファイルを直したあとに使う）"

    lib_name: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        lib = bpy.data.libraries.get(self.lib_name)
        if lib is None:
            return {"CANCELLED"}
        lib.reload()
        self.report({"INFO"}, "「%s」を読み直したよ" % self.lib_name)
        return {"FINISHED"}


class MAJREF_OT_reload_all(Operator):
    bl_idname = "majref.reload_all"
    bl_label = "全部読み直す"
    bl_description = "リンク中の全ライブラリを読み直す"

    def execute(self, context):
        libs = list(bpy.data.libraries)
        if not libs:
            self.report({"WARNING"}, "リンク中のものは無いよ")
            return {"CANCELLED"}
        for lib in libs:
            lib.reload()
        self.report({"INFO"}, "%d 件のライブラリを読み直したよ" % len(libs))
        return {"FINISHED"}


class MAJREF_OT_relocate(Operator):
    bl_idname = "majref.relocate"
    bl_label = "場所を変える"
    bl_description = "ライブラリの参照先ファイルを変更する（ファイルの移動・改名のあとに）"

    lib_name: StringProperty(options={"HIDDEN"})
    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.blend", options={"HIDDEN"})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        lib = bpy.data.libraries.get(self.lib_name)
        if lib is None:
            return {"CANCELLED"}
        lib.filepath = self.filepath
        lib.reload()
        self.report({"INFO"}, "「%s」の場所を変えて読み直したよ" % self.lib_name)
        return {"FINISHED"}


class MAJREF_OT_make_local(Operator):
    bl_idname = "majref.make_local"
    bl_label = "ローカルにする（切り離す）"
    bl_description = "選んだものをこのファイル専用にコピーして、元ファイルとのつながりを切る（Mayaのリファレンスのインポート）"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        try:
            with context.temp_override(view_layer=context.view_layer,
                                       active_object=obj, selected_objects=[obj]):
                bpy.ops.object.make_local(type="SELECT_OBJECT_AND_DATA")
        except Exception as exc:
            self.report({"ERROR"}, "ローカル化に失敗: %s" % exc)
            return {"CANCELLED"}
        self.report({"INFO"}, "ローカルにしたよ。もう元ファイルを直しても影響せえへんよ")
        return {"FINISHED"}


# ---------------------------------------------------------------- panels

class MAJIMERU_PT_reference(Panel):
    bl_idname = "MAJIMERU_PT_reference"
    bl_label = "リファレンス"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Majimeru"

    def draw(self, context):
        layout = self.layout
        props = context.scene.maj_ref

        layout.label(text="元ファイル（.blend）", icon="FILE_BLEND")
        row = layout.row(align=True)
        row.prop(props, "src_file", text="")
        row.operator("majref.pick_file", text="", icon="FILE_FOLDER")
        layout.operator("majref.scan", icon="VIEWZOOM")

        names = []
        try:
            names = json.loads(props.names_json or "[]")
        except Exception:
            names = []
        if names:
            layout.prop(props, "collection")
        layout.prop(props, "auto_override")

        col = layout.column()
        col.scale_y = 1.5
        col.operator("majref.link", icon="LINKED")

        layout.separator()
        layout.label(text="リンク中のファイル", icon="LIBRARY_DATA_DIRECT")
        libs = list(bpy.data.libraries)
        if not libs:
            layout.label(text="（まだ無いよ）")
        for lib in libs:
            box = layout.box()
            box.label(text=lib.name, icon="LINKED")
            row = box.row(align=True)
            op = row.operator("majref.reload_one", text="読み直す", icon="FILE_REFRESH")
            op.lib_name = lib.name
            op = row.operator("majref.relocate", text="場所を変える", icon="FOLDER_REDIRECT")
            op.lib_name = lib.name
        if libs:
            layout.operator("majref.reload_all", icon="FILE_REFRESH")


class MAJIMERU_PT_reference_more(Panel):
    bl_idname = "MAJIMERU_PT_reference_more"
    bl_label = "選んだものへの操作・使い方"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Majimeru"
    bl_parent_id = "MAJIMERU_PT_reference"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        layout.operator("majref.override_selected", icon="LIBRARY_DATA_OVERRIDE")
        layout.operator("majref.make_local", icon="UNLINKED")
        layout.separator()
        layout.label(text="使い方（Mayaとの対応）")
        for line in (
            "リファレンス読み込み ＝ リンクする",
            "アニメーション付け ＝ オーバーライド",
            "形を直すときは元ファイルを開く",
            "元を直したら「読み直す」で反映",
            "切り離すときは「ローカルにする」",
        ):
            layout.label(text=line)


# ---------------------------------------------------------------- register

classes = (
    MAJREF_Props,
    MAJREF_OT_pick_file,
    MAJREF_OT_scan,
    MAJREF_OT_link,
    MAJREF_OT_override_selected,
    MAJREF_OT_reload_one,
    MAJREF_OT_reload_all,
    MAJREF_OT_relocate,
    MAJREF_OT_make_local,
    MAJIMERU_PT_reference,
    MAJIMERU_PT_reference_more,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.maj_ref = bpy.props.PointerProperty(type=MAJREF_Props)


def unregister():
    del bpy.types.Scene.maj_ref
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
